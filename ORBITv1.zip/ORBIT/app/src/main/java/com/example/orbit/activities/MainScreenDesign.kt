package com.example.orbit.activities

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.orbit.ui.theme.ORBITTheme // Import your custom theme

@Composable
fun MainScreenDesign(navController: NavController, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xff477876),
                        Color(0xff3d4d75),
                        Color(0xff192239)
                    ),
                    center = Offset.Unspecified,
                    radius = Float.POSITIVE_INFINITY
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // --- "ORBIT" Title - Now uses the theme style ---
            Text(
                text = "ORBIT",
                color = Color.White,
                // This will use the font you defined for displayLarge in your theme
                style = MaterialTheme.typography.displayLarge
            )

            Spacer(modifier = Modifier.height(16.dp))

            // --- Subtitle - Now uses the theme style ---
            Text(
                text = "Offline Research  Book Information Tracker",
                color = Color.White,
                textAlign = TextAlign.Center,
                // This will use the font you defined for headlineLarge in your theme
                style = MaterialTheme.typography.headlineLarge,
                modifier = Modifier.padding(horizontal = 32.dp)
            )

            Spacer(modifier = Modifier.height(100.dp))

            // --- "ARE YOU AN ADMIN?" - Now uses the theme style ---
            Text(
                text = "ARE YOU AN ADMIN?",
                color = Color(0xFFA4B2EB),
                textAlign = TextAlign.Center,
                // This will use the font you defined for headlineMedium in your theme
                style = MaterialTheme.typography.headlineMedium
            )

            Spacer(modifier = Modifier.height(24.dp))

            // --- Reusable button with correct navigation ---
            AuthButton(
                text = "Yes",
                onClick = { navController.navigate("admin") }
            )

            Spacer(modifier = Modifier.height(16.dp))

            AuthButton(
                text = "No",
                onClick = { navController.navigate("auth_choice") } // Routes to Login/Signup choice
            )
        }
    }
}

// Reusable button
@Composable
private fun AuthButton(text: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .width(170.dp)
            .height(53.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(color = Color(0xFFD9D9D9).copy(alpha = 0.5f))
            .border(
                border = BorderStroke(2.dp, Color.Black),
                shape = RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        // --- Button Text - Now uses the theme style ---
        Text(
            text = text,
            color = Color.White,
            // This will use the font you defined for labelLarge in your theme
            style = MaterialTheme.typography.labelLarge
        )
    }
}

// Preview now wrapped in your theme to show fonts correctly
@Preview(showBackground = true, widthDp = 1280, heightDp = 800)
@Composable
private fun MainScreenDesignPreview() {
    ORBITTheme {
        val navController = rememberNavController()
        MainScreenDesign(navController = navController)
    }
}
