package com.example.orbit.database


import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "books",
    indices = [Index(value = ["isbn"], unique = true)]
)
data class Book(
    @PrimaryKey val isbn: String,
    val title: String,
    val author: String,
    val year: Int,
    val category: String,
    val availability: Boolean
)

