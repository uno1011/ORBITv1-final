package com.example.orbit.activities

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.launch
import androidx.compose.ui.text.font.FontWeight

@Composable
fun AdminScreen(navController: NavController) {
    var password by remember { mutableStateOf(TextFieldValue("")) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // --- NEW STATE VARIABLE TO TRIGGER NAVIGATION SAFELY ---
    var shouldNavigateToDashboard by remember { mutableStateOf(false) }
    // --------------------------------------------------------

    // --- THIS LaunchedEffect HANDLES NAVIGATION SAFELY ---
    LaunchedEffect(shouldNavigateToDashboard) {
        if (shouldNavigateToDashboard) {
            // When the state becomes true, this block runs and navigates.
            navController.navigate("admin_dashboard")
            shouldNavigateToDashboard = false // Reset the state after navigating
        }
    }
    // ------------------------------------------------------

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xff477876), Color(0xff3d4d75), Color(0xff192239)),
                    center = Offset(193.13f, 653.65f),
                    radius = 1121.95f
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 64.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Text(
                text = "ORBIT",
                color = Color.White,
                fontSize = 80.sp,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.displayLarge
            )

            Spacer(modifier = Modifier.height(32.dp))

            Text(
                text = "HELLO ADMIN!",
                color = Color(0xffa4b2eb),
                style = MaterialTheme.typography.headlineMedium
            )

            Spacer(modifier = Modifier.height(48.dp))

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Enter password", color = Color(0xffa7a2a2)) },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                shape = RoundedCornerShape(15.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xff1b2e5d),
                    unfocusedBorderColor = Color(0xff1b2e5d),
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black,
                    cursorColor = Color.Black,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                ),
                modifier = Modifier
                    .width(512.dp)
                    .border(
                        width = 2.dp,
                        color = Color(0xff1b2e5d),
                        shape = RoundedCornerShape(15.dp)
                    )
            )

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = {
                    // --- THE BUTTON ONCLICK LOGIC IS NOW SIMPLER ---
                    if (password.text == "admin2025") {
                        // Instead of navigating, just update the state
                        shouldNavigateToDashboard = true
                    } else {
                        Toast.makeText(context, "Incorrect Password", Toast.LENGTH_SHORT).show()
                    }
                    // ---------------------------------------------
                },
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Log In", fontSize = 18.sp)
            }
        }

        Button(
            onClick = { navController.popBackStack() },
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xffd9d9d9).copy(alpha = 0.5f)),
            border = BorderStroke(2.dp, Color.Black)
        ) {
            Text("BACK", color = Color.White)
        }
    }
}
