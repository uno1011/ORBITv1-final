package com.example.orbit.activities

import android.Manifest
import android.content.pm.PackageManager
import android.telephony.SmsManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.example.orbit.database.AppDatabase
import com.example.orbit.database.Book
import com.example.orbit.database.Transaction
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors

@Composable
fun QRCodeScannerScreen(navController: NavController, studentNumber: String) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var hasCameraPermission by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }

    var isLoading by remember { mutableStateOf(false) }
    var foundBook by remember { mutableStateOf<Book?>(null) }
    var scanError by remember { mutableStateOf(false) }

    val db = remember { AppDatabase.getDatabase(context) }
    val scope = rememberCoroutineScope()

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { granted -> hasCameraPermission = granted }
    )

    LaunchedEffect(key1 = true) {
        if (!hasCameraPermission) {
            launcher.launch(Manifest.permission.CAMERA)
        }
    }

    val qrCodeAnalyzer = remember { QrCodeAnalyzer { isbn ->
        scope.launch {
            isLoading = true
            scanError = false
            val book = withContext(Dispatchers.IO) {
                db.bookDao().getBookByIsbn(isbn)
            }
            if (book != null) {
                foundBook = book
            } else {
                scanError = true
            }
            isLoading = false
        }
    }}

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xff477876), Color(0xff3d4d75), Color(0xff192239)),
                    center = Offset(193.13f, 653.65f),
                    radius = 1121.95f
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 64.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Text(
                text = "ORBIT",
                color = Color.White,
                style = MaterialTheme.typography.displayLarge
            )
            Spacer(modifier = Modifier.height(32.dp))
            Text(
                text = "SCAN BOOK QR CODE",
                color = Color(0xffa4b2eb),
                style = MaterialTheme.typography.headlineMedium,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(48.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(24.dp))
                    .border(BorderStroke(4.dp, Color.White), RoundedCornerShape(24.dp))
            ) {
                if (hasCameraPermission) {
                    AndroidView(
                        factory = { ctx ->
                            val previewView = PreviewView(ctx)
                            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                            cameraProviderFuture.addListener({
                                val cameraProvider = cameraProviderFuture.get()
                                val preview = Preview.Builder().build().also {
                                    it.setSurfaceProvider(previewView.surfaceProvider)
                                }
                                val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA
                                val imageAnalysis = ImageAnalysis.Builder()
                                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                    .build()
                                    .also {
                                        it.setAnalyzer(Executors.newSingleThreadExecutor(), qrCodeAnalyzer)
                                    }
                                try {
                                    cameraProvider.unbindAll()
                                    cameraProvider.bindToLifecycle(lifecycleOwner, cameraSelector, preview, imageAnalysis)
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }, ContextCompat.getMainExecutor(ctx))
                            previewView
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center){
                        Text("Camera permission is required to scan QR codes.", color = Color.White, textAlign = TextAlign.Center)
                    }
                }
            }
        }

        Button(
            onClick = { navController.popBackStack() },
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xffd9d9d9).copy(alpha = 0.5f)),
            border = BorderStroke(2.dp, Color.Black)
        ) {
            Text("BACK", color = Color.White)
        }

        if (isLoading) {
            CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
        }
        if (scanError) {
            OverlayBox(text = "Book not found!") {
                scanError = false
                qrCodeAnalyzer.resumeScanning()
            }
        }
        foundBook?.let { book ->
            BookDetailsOverlay(navController = navController, book = book, onDismiss = {
                foundBook = null
                qrCodeAnalyzer.resumeScanning()
            }) {
                scope.launch(Dispatchers.IO) {
                    // --- 1. PRE-CHECK AVAILABILITY ---
                    // We fetch the latest data from the DB to be 100% sure
                    val latestBook = db.bookDao().getBookByIsbn(book.isbn)

                    if (latestBook != null && latestBook.availability) {
                        // CASE: Book is actually available
                        val updatedBook = latestBook.copy(availability = false)
                        db.bookDao().update(updatedBook)

                        val transaction = Transaction(
                            bookIsbn = latestBook.isbn,
                            studentNumber = studentNumber,
                            dateBorrowed = System.currentTimeMillis(),
                            dateToBeReturned = System.currentTimeMillis() + 60000 // 1 min for testing
                        )
                        db.transactionDao().insert(transaction)

                        // Immediate SMS logic
                        try {
                            val student = db.studentDao().getStudentByNumber(studentNumber)
                            if (student != null) {
                                val smsManager = context.getSystemService(SmsManager::class.java)
                                val message = "ORBIT Reminder: You have borrowed '${latestBook.title}'. It is due in 1 minute."
                                smsManager.sendTextMessage(student.contactNumber, null, message, null, null)
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }

                        withContext(Dispatchers.Main) {
                            Toast.makeText(context, "Borrow Successful!", Toast.LENGTH_SHORT).show()
                            foundBook = updatedBook // Update UI
                        }
                    } else {
                        // CASE: Book was already borrowed
                        withContext(Dispatchers.Main) {
                            Toast.makeText(context, "Book already borrowed!", Toast.LENGTH_LONG).show()
                            // Update the local state so the UI shows "Borrowed" immediately
                            foundBook = latestBook
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BookDetailsOverlay(navController: NavController, book: Book, onDismiss: () -> Unit, onBorrow: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.6f))
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.background(Color.White, shape = MaterialTheme.shapes.medium).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(book.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))
            Text("by ${book.author}")
            Spacer(modifier = Modifier.height(16.dp))
            if (book.availability) {
                Text("Status: Available", color = Color(0xFF008000), fontSize = 18.sp)
            } else {
                Text("Status: Book is Borrowed", color = Color.Red, fontSize = 18.sp)
            }
            Spacer(modifier = Modifier.height(24.dp))
            Button(onClick = onBorrow, enabled = book.availability) {
                Text("Borrow This Book")
            }
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = onDismiss) {
                Text("Scan Another")
            }
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = { navController.popBackStack() }) {
                Text("Back to Home")
            }
        }
    }
}

@Composable
fun OverlayBox(text: String, onDismiss: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.6f)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.background(Color.White, shape = MaterialTheme.shapes.medium).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text, fontSize = 20.sp)
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = onDismiss) {
                Text("OK")
            }
        }
    }
}

class QrCodeAnalyzer(private val onQrCodeScanned: (String) -> Unit) : ImageAnalysis.Analyzer {
    private val options = BarcodeScannerOptions.Builder()
        .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
        .build()
    private val scanner = BarcodeScanning.getClient(options)
    private var isScanning = true

    fun resumeScanning() {
        isScanning = true
    }

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        if (!isScanning) {
            imageProxy.close()
            return
        }
        val mediaImage = imageProxy.image
        if (mediaImage != null) {
            val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
            scanner.process(image)
                .addOnSuccessListener { barcodes ->
                    if (barcodes.isNotEmpty()) {
                        isScanning = false
                        barcodes.first().rawValue?.let { onQrCodeScanned(it) }
                    }
                }
                .addOnCompleteListener { imageProxy.close() }
        }
    }
}
