package com.example.orbit.activities
import  com.example.orbit.ui.theme.ORBITTheme
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ORBITTheme{}
            val navController = rememberNavController()
            NavHost(navController = navController, startDestination = "main") {
                composable("main") {
                    MainScreen(navController = navController)
                }
                composable("auth_choice") {
                    AuthChoiceScreen(navController = navController)

                }
                composable("login") {
                    LoginScreen(navController = navController)
                }
                composable("signup") {
                    SignUpScreen(navController = navController)
                }
                composable(
                    route = "studentNumber/{number}",
                    arguments = listOf(navArgument("number") { type = NavType.StringType })
                ) {
                    val studentNumber = it.arguments?.getString("number") ?: ""
                    StudentNumberScreen(navController = navController, studentNumber = studentNumber)
                }
                composable(
                    route = "student/{studentNumber}",
                    arguments = listOf(navArgument("studentNumber") { type = NavType.StringType })
                ) {
                    val studentNumber = it.arguments?.getString("studentNumber") ?: ""
                    StudentScreen(navController = navController, studentNumber = studentNumber)
                }
                composable("admin") {
                    AdminScreen(navController = navController)
                }
                composable("admin_dashboard") {
                    AdminDashboardScreen(navController = navController)
                }
                composable(
                    route = "return/{studentNumber}",
                    arguments = listOf(navArgument("studentNumber") { type = NavType.StringType })
                ) {
                    val studentNumber = it.arguments?.getString("studentNumber") ?: ""
                    ReturnScreen(navController = navController, studentNumber = studentNumber)
                }
                composable(
                    route = "qr_scanner/{studentNumber}",
                    arguments = listOf(navArgument("studentNumber") { type = NavType.StringType })
                ) {
                    val studentNumber = it.arguments?.getString("studentNumber") ?: ""
                    QRCodeScannerScreen(navController = navController, studentNumber = studentNumber)
                }
                composable(
                    route = "return_scanner/{transactionId}/{expectedIsbn}",
                    arguments = listOf(
                        navArgument("transactionId") { type = NavType.IntType },
                        navArgument("expectedIsbn") { type = NavType.StringType }
                    )
                ) {
                    val transactionId = it.arguments?.getInt("transactionId") ?: 0
                    val expectedIsbn = it.arguments?.getString("expectedIsbn") ?: ""
                    ReturnScannerScreen(navController = navController, transactionId = transactionId, expectedIsbn = expectedIsbn)
                }
            }
        }
    }
}

@Composable
fun MainScreen(navController: NavController) {
    MainScreenDesign(navController = navController, modifier = Modifier.fillMaxSize())
}
