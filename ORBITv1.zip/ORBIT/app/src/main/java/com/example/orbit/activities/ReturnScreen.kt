package com.example.orbit.activities

import android.util.Log
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.orbit.database.AppDatabase
import com.example.orbit.database.Book
import com.example.orbit.database.Transaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Data class remains the same
data class BorrowedBookInfo(val transaction: Transaction, val book: Book?)

@Composable
fun ReturnScreen(navController: NavController, studentNumber: String) {
    val context = LocalContext.current
    val db = remember { AppDatabase.getDatabase(context) }
    var borrowedBooks by remember { mutableStateOf<List<BorrowedBookInfo>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()

    // Data fetching logic remains the same
    fun fetchBorrowedBooks() {
        scope.launch {
            isLoading = true
            withContext(Dispatchers.IO) {
                val transactions = db.transactionDao().getBorrowedBooksByUser(studentNumber)
                val bookInfos = transactions.map {
                    BorrowedBookInfo(transaction = it, book = db.bookDao().getBookByIsbn(it.bookIsbn))
                }
                withContext(Dispatchers.Main) {
                    borrowedBooks = bookInfos
                    isLoading = false
                }
            }
        }
    }

    LaunchedEffect(key1 = studentNumber) {
        fetchBorrowedBooks()
    }

    // --- NEW LAYOUT BASED ON YOUR DESIGN ---
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xff477876), Color(0xff3d4d75), Color(0xff192239)),
                    center = Offset(193.13f, 653.65f),
                    radius = 1121.95f
                )
            )
    ) {
        // Decorative circle from design
        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .offset(x = (-65).dp, y = (-101).dp)
                .size(300.dp)
                .clip(shape = CircleShape)
                .background(
                    brush = Brush.linearGradient(
                        0f to Color(0xff1d264a),
                        1f to Color(0xff467775),
                        start = Offset(116f, 118.5f),
                        end = Offset(221f, 260.5f)
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "Your Borrowed Books",
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White // Set text color to white
            )
            Spacer(modifier = Modifier.height(16.dp))

            if (isLoading) {
                CircularProgressIndicator(modifier = Modifier.padding(top = 64.dp))
            } else if (borrowedBooks.isEmpty()) {
                // Display the "No books" message from your design when the list is empty
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "You have no books to return!",
                        color = Color(0xffa4b2eb),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.headlineMedium,
                        lineHeight = 1.5.sp
                    )
                }
            } else {
                // Display the list of books
                LazyColumn {
                    items(borrowedBooks) { info ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    info.book?.title ?: "Unknown Book",
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White // Set text color to white
                                )
                                Text(
                                    "Due: ${formatDate(info.transaction.dateToBeReturned)}",
                                    color = Color.LightGray // Set text color to light gray
                                )
                            }
                            Button(
                                onClick = {
                                    navController.navigate("return_scanner/${info.transaction.id}/${info.book?.isbn}")
                                }
                            ) {
                                Text("Return")
                            }
                        }
                        Divider(color = Color.White.copy(alpha = 0.5f))
                    }
                }
            }
        }
        // Functional "BACK" button
        Button(
            onClick = { navController.popBackStack() },
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xffd9d9d9).copy(alpha = 0.5f)),
            border = BorderStroke(2.dp, Color.Black)
        ) {
            Text("BACK", color = Color.White)
        }
    }
}

// Helper function to format the date remains the same
private fun formatDate(timestamp: Long): String {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    return sdf.format(Date(timestamp))
}
