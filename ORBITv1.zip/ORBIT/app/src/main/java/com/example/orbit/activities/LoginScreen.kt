package com.example.orbit.activities

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.orbit.database.AppDatabase

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun LoginScreen(navController: NavController) {

    var studentNumber by remember { mutableStateOf(TextFieldValue("")) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val db = remember { AppDatabase.getDatabase(context) }

    // --- NEW STATE VARIABLE TO TRIGGER NAVIGATION SAFELY ---
    var studentNumberToNavigate by remember { mutableStateOf<String?>(null) }
    // --------------------------------------------------------

    // --- FORGOT STUDENT NUMBER STATES ---
    var showForgotDialog by remember { mutableStateOf(false) }
    var recoveryMethod by remember { mutableStateOf<String?>(null) } // "LRN" or "PHONE"
    var recoveryInput by remember { mutableStateOf(TextFieldValue("")) }
    var recoveredStudentNumber by remember { mutableStateOf<String?>(null) }
    var recoveryError by remember { mutableStateOf<String?>(null) }
    // ------------------------------------

    // --- THIS LaunchedEffect HANDLES NAVIGATION SAFELY ---
    LaunchedEffect(studentNumberToNavigate) {
        studentNumberToNavigate?.let { number ->
            // When the state changes, this block runs and navigates.
            navController.navigate("student/$number")
            studentNumberToNavigate = null // Reset the state after navigating
        }
    }
    // ------------------------------------------------------

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xff477876), Color(0xff3d4d75), Color(0xff192239)),
                    center = Offset(193.13f, 653.65f),
                    radius = 1121.95f
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 64.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Text(
                text = "ORBIT",
                color = Color.White,
                style = MaterialTheme.typography.displayLarge
            )

            Text(
                text = "Offline Research  Book Information Tracker",
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 32.dp),
                style = MaterialTheme.typography.headlineSmall
            )

            Spacer(modifier = Modifier.height(64.dp))

            Text(
                text = "INPUT STUDENT NUMBER",
                color = Color(0xffa4b2eb),
                style = MaterialTheme.typography.headlineMedium
            )

            Spacer(modifier = Modifier.height(24.dp))

            OutlinedTextField(
                value = studentNumber,
                onValueChange = { studentNumber = it },
                label = { Text("Enter student no.", color = Color(0xffa7a2a2)) },
                singleLine = true,
                shape = RoundedCornerShape(15.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xff1b2e5d),
                    unfocusedBorderColor = Color(0xff1b2e5d),
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black,
                    cursorColor = Color.Black,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                ),
                modifier = Modifier
                    .width(512.dp)
                    .border(
                        width = 2.dp,
                        color = Color(0xff1b2e5d),
                        shape = RoundedCornerShape(15.dp)
                    )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Forgot Student Number?",
                color = Color.White,
                fontSize = 14.sp,
                textDecoration = TextDecoration.Underline,
                modifier = Modifier.clickable {
                    showForgotDialog = true
                    recoveryMethod = null
                    recoveryInput = TextFieldValue("")
                    recoveredStudentNumber = null
                    recoveryError = null
                }
            )

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = {
                    // --- THE BUTTON ONCLICK LOGIC IS NOW SIMPLER ---
                    val numberAsString = studentNumber.text.trim()
                    if (numberAsString.isBlank()) {
                        Toast.makeText(context, "Please enter a student number.", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    scope.launch(Dispatchers.IO) {
                        val student = db.studentDao().getStudentByNumber(numberAsString)
                        withContext(Dispatchers.Main) {
                            if (student != null) {
                                // Instead of navigating, just update the state
                                studentNumberToNavigate = numberAsString
                            } else {
                                Toast.makeText(context, "Student number not found.", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                    // ---------------------------------------------
                },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xff78008b)),
                border = BorderStroke(2.dp, Color.Black)
            ) {
                Text("ENTER", fontSize = 24.sp, modifier = Modifier.padding(horizontal = 32.dp))
            }
        }

        Button(
            onClick = { navController.popBackStack() },
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xffd9d9d9).copy(alpha = 0.5f)),
            border = BorderStroke(2.dp, Color.Black)
        ) {
            Text("BACK", color = Color.White)
        }

        // --- FORGOT PASSWORD DIALOG ---
        if (showForgotDialog) {
            AlertDialog(
                onDismissRequest = { showForgotDialog = false },
                title = { Text(text = "Recover Student Number") },
                text = {
                    Column {
                        if (recoveredStudentNumber != null) {
                            Text("Your Student Number is:")
                            Text(
                                text = recoveredStudentNumber!!,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xff78008b),
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        } else if (recoveryMethod == null) {
                            Text("Choose recovery method:")
                            Spacer(modifier = Modifier.height(16.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly
                            ) {
                                Button(onClick = { recoveryMethod = "LRN" }) { Text("LRN") }
                                Button(onClick = { recoveryMethod = "PHONE" }) { Text("Phone") }
                            }
                        } else {
                            Text("Enter your ${if (recoveryMethod == "LRN") "LRN" else "Phone Number"}:")
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = recoveryInput,
                                onValueChange = { recoveryInput = it },
                                label = { Text(if (recoveryMethod == "LRN") "LRN" else "Phone Number") },
                                singleLine = true
                            )
                            if (recoveryError != null) {
                                Text(
                                    text = recoveryError!!,
                                    color = Color.Red,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    if (recoveredStudentNumber != null) {
                        Button(onClick = {
                            studentNumberToNavigate = recoveredStudentNumber
                            showForgotDialog = false
                        }) {
                            Text("Login")
                        }
                    } else if (recoveryMethod != null) {
                        Button(onClick = {
                            scope.launch(Dispatchers.IO) {
                                val input = recoveryInput.text.trim()
                                val student = if (recoveryMethod == "LRN") {
                                    db.studentDao().getStudentByLrn(input)
                                } else {
                                    db.studentDao().getStudentByPhoneNumber(input)
                                }

                                withContext(Dispatchers.Main) {
                                    if (student != null) {
                                        recoveredStudentNumber = student.studentNumber
                                        recoveryError = null
                                    } else {
                                        recoveryError = "No student found with this info."
                                    }
                                }
                            }
                        }) {
                            Text("Find")
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showForgotDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}
