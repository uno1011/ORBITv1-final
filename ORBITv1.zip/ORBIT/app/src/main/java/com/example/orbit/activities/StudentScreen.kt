package com.example.orbit.activities

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun StudentScreen(navController: NavController, studentNumber: String) { // Receive studentNumber
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Button(onClick = { navController.navigate("qr_scanner/$studentNumber") }) { // Pass studentNumber
            Text("Borrow")
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = { navController.navigate("return/$studentNumber") }) { // Pass studentNumber
            Text("Return")
        }
        Spacer(modifier = Modifier.height(32.dp))
        Button(onClick = { 
            // Pop back to the "main" route (which is the start destination)
            // inclusive = false means we keep "main" in the stack
            navController.popBackStack("main", inclusive = false) 
        }) {
            Text("Log Out")
        }
    }
}
