package com.example.orbit

import android.app.Application
import androidx.work.*
import com.example.orbit.workers.OverdueCheckWorker
import java.util.concurrent.TimeUnit

class OrbitApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        setupRecurringWork()
    }

    private fun setupRecurringWork() {
        // NOTE: 15 minutes is the absolute minimum interval allowed by the Android OS
        // for periodic background work.
        val repeatingRequest = PeriodicWorkRequestBuilder<OverdueCheckWorker>(15, TimeUnit.MINUTES)
            .build()

        WorkManager.getInstance(applicationContext).enqueueUniquePeriodicWork(
            "OverdueCheckWorker",
            ExistingPeriodicWorkPolicy.KEEP,
            repeatingRequest
        )
    }
}
