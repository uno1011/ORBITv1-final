package com.example.orbit.activities

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.requiredHeight
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.requiredWidth
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.example.orbit.R

// This is NOW just the design. It is renamed and doesn't know about navigation.
@Composable
fun LgSignDesign(
    modifier: Modifier = Modifier,
    onYesClick: () -> Unit, // It receives an action for the "Yes" click
    onNoClick: () -> Unit   // It receives an action for the "No" click
) {
    Box(
        modifier = modifier
            .requiredWidth(width = 1280.dp)
            .requiredHeight(height = 800.dp)
            .rotate(degrees = -90f)
            .background(brush = Brush.radialGradient(
                0.1f to Color(0xff477876),
                0.46f to Color(0xff3d4d75),
                1f to Color(0xff192239),
                center = Offset(193.13f, 653.65f),
                radius = 1121.95f))
    ) {
        Text(
            text = " ",
            color = Color.White,
            textAlign = TextAlign.Center,
            lineHeight = 4.37.em,
            style = MaterialTheme.typography.headlineLarge,
            modifier = Modifier
                .align(alignment = Alignment.TopStart)
                .offset(x = 422.dp,
                    y = 501.dp)
                .rotate(degrees = -180f)
                .wrapContentHeight(align = Alignment.CenterVertically))
        Text(
            text = "No",
            color = Color.White,
            style = MaterialTheme.typography.displaySmall,
            modifier = Modifier
                .align(alignment = Alignment.TopStart)
                .offset(x = 391.dp,
                    y = 665.dp)
                .rotate(degrees = -180f))
        Text(
            text = "Yes",
            color = Color.White,
            style = MaterialTheme.typography.displaySmall,
            modifier = Modifier
                .align(alignment = Alignment.TopStart)
                .offset(x = 383.dp,
                    y = 579.dp)
                .rotate(degrees = -180f))
        Image(
            painter = painterResource(id = R.drawable.ellipse1),
            contentDescription = "Ellipse 1",
            modifier = Modifier
                .align(alignment = Alignment.TopStart)
                .offset(x = 341.dp,
                    y = 579.dp)
                .requiredSize(size = 1000.dp)
                .rotate(degrees = -180f))
        // "Yes" button Box
        Box(
            modifier = Modifier
                .align(alignment = Alignment.TopStart)
                .offset(x = 331.dp,
                    y = 574.dp)
                .requiredWidth(width = 170.dp)
                .requiredHeight(height = 53.dp)
                .clip(shape = RoundedCornerShape(10.dp))
                .rotate(degrees = -180f)
                .background(color = Color(0xffd9d9d9).copy(alpha = 0.5f))
                .border(border = BorderStroke(2.dp, Color.Black),
                    shape = RoundedCornerShape(10.dp))
                .shadow(elevation = 4.dp,
                    shape = RoundedCornerShape(10.dp))
                .clickable(onClick = onYesClick) // Use the passed-in click action
        )
        // "No" button Box
        Box(
            modifier = Modifier
                .align(alignment = Alignment.TopStart)
                .offset(x = 331.dp,
                    y = 660.dp)
                .requiredWidth(width = 170.dp)
                .requiredHeight(height = 53.dp)
                .clip(shape = RoundedCornerShape(10.dp))
                .rotate(degrees = -180f)
                .background(color = Color(0xffd9d9d9).copy(alpha = 0.5f))
                .border(border = BorderStroke(2.dp, Color.Black),
                    shape = RoundedCornerShape(10.dp))
                .shadow(elevation = 4.dp,
                    shape = RoundedCornerShape(10.dp))
                .clickable(onClick = onNoClick) // Use the passed-in click action
        )
        Text(
            text = "ARE YOU AN ADMIN?",
            color = Color(0xffa4b2eb),
            textAlign = TextAlign.Center,
            lineHeight = 2.92.em,
            style = TextStyle(
                fontSize = 48.sp),
            modifier = Modifier
                .align(alignment = Alignment.TopStart)
                .offset(x = 176.dp,
                    y = 451.dp)
                .rotate(degrees = -180f)
                .wrapContentHeight(align = Alignment.CenterVertically))
        Text(
            text = "ORBIT",
            color = Color.White,
            textAlign = TextAlign.Center,
            lineHeight = 1.09.em,
            style = TextStyle(
                fontSize = 128.sp),
            modifier = Modifier
                .align(alignment = Alignment.TopStart)
                .offset(x = 94.dp,
                    y = 86.dp)
                .requiredWidth(width = 644.dp)
                .requiredHeight(height = 210.dp)
                .rotate(degrees = -180f)
                .wrapContentHeight(align = Alignment.CenterVertically))
        Text(
            text = "Offline Research  Book Information Tracker",
            color = Color.White,
            textAlign = TextAlign.Center,
            lineHeight = 4.37.em,
            style = MaterialTheme.typography.headlineLarge,
            modifier = Modifier
                .align(alignment = Alignment.TopCenter)
                .offset(x = (-224.5).dp,
                    y = 274.dp)
                .requiredWidth(width = 675.dp)
                .rotate(degrees = -180f)
                .wrapContentHeight(align = Alignment.CenterVertically))
        Box(
            modifier = Modifier
                .align(alignment = Alignment.TopStart)
                .offset(x = (-65).dp,
                    y = (-101).dp)
                .requiredSize(size = 300.dp)
                .clip(shape = CircleShape)
                .rotate(degrees = -180f)
                .background(brush = Brush.linearGradient(
                    0f to Color(0xff1d264a),
                    1f to Color(0xff467775),
                    start = Offset(116f, 118.5f),
                    end = Offset(221f, 260.5f))))
    }
}

@Preview(widthDp = 1280, heightDp = 800)
@Composable
private fun LgSignDesignPreview() {
    LgSignDesign(Modifier, onYesClick = {}, onNoClick = {})
}
