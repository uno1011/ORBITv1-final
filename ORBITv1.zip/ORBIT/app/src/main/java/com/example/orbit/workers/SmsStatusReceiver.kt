package com.example.orbit.workers

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class SmsStatusReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        when (resultCode) {
            Activity.RESULT_OK -> {
                Log.d("SmsStatusReceiver", "SMS delivered successfully to the carrier.")
            }
            else -> {
                Log.e("SmsStatusReceiver", "SMS failed to send. Error code: $resultCode")
            }
        }
    }
}
