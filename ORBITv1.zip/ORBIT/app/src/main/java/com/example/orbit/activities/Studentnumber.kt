package com.example.orbit.activities

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun StudentNumberScreen(navController: NavController, studentNumber: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Sign-up successful!")
        Spacer(modifier = Modifier.height(16.dp))
        Text("Your new Student Number is:")

        Text(
            text = studentNumber,
            style = MaterialTheme.typography.headlineLarge,
            modifier = Modifier.padding(vertical = 24.dp)
        )

        Button(onClick = { navController.navigate("student/$studentNumber") }) {
            Text("Proceed")
        }
        
        Spacer(modifier = Modifier.height(16.dp))

        // Added Back button as requested
        Button(onClick = { navController.popBackStack() }) {
            Text("Back")
        }
    }
}
