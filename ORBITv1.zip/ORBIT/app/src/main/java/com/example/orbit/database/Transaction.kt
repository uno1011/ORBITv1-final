package com.example.orbit.database

import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val bookIsbn: String,
    val studentNumber: String,
    val dateBorrowed: Long,
    val dateToBeReturned: Long,
    val dateReturned: Long? = null
)
{
}