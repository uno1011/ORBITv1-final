package com.example.orbit.activities

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.example.orbit.database.AppDatabase
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors

@Composable
fun ReturnScannerScreen(navController: NavController, transactionId: Int, expectedIsbn: String) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var hasCameraPermission by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }

    var scanResult by remember { mutableStateOf<String?>(null) }

    val db = remember { AppDatabase.getDatabase(context) }
    val scope = rememberCoroutineScope()

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { granted -> hasCameraPermission = granted }
    )

    LaunchedEffect(key1 = true) {
        if (!hasCameraPermission) {
            launcher.launch(Manifest.permission.CAMERA)
        }
    }

    val qrCodeAnalyzer = remember {
        QrCodeAnalyzer { isbn ->
            if (isbn == expectedIsbn) {
                scope.launch(Dispatchers.IO) {
                    val transaction = db.transactionDao().getTransactionById(transactionId)
                    if (transaction != null) {
                        db.transactionDao().update(transaction.copy(dateReturned = System.currentTimeMillis()))
                        val book = db.bookDao().getBookByIsbn(expectedIsbn)
                        if (book != null) {
                            db.bookDao().update(book.copy(availability = true))
                        }
                        withContext(Dispatchers.Main) { scanResult = "Success" }
                    }
                }
            } else {
                scope.launch(Dispatchers.Main) { scanResult = "Error" }
            }
        }
    }

    // --- This is the new layout structure ---
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xff477876), Color(0xff3d4d75), Color(0xff192239)),
                    center = Offset(193.13f, 653.65f),
                    radius = 1121.95f
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 64.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Text(
                text = "ORBIT",
                color = Color.White,
                style = MaterialTheme.typography.displayLarge
            )
            Spacer(modifier = Modifier.height(32.dp))
            Text(
                text = "SCAN BOOK TO RETURN", // Updated prompt for clarity
                color = Color(0xffa4b2eb),
                style = MaterialTheme.typography.headlineMedium,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(48.dp))

            // Box to contain the camera preview
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(24.dp)) // Clip the camera feed
                    .border(BorderStroke(4.dp, Color.White), RoundedCornerShape(24.dp))
            ) {
                if (hasCameraPermission) {
                    AndroidView(
                        factory = { ctx ->
                            val previewView = PreviewView(ctx)
                            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                            cameraProviderFuture.addListener({
                                val cameraProvider = cameraProviderFuture.get()
                                val preview = Preview.Builder().build().also {
                                    it.setSurfaceProvider(previewView.surfaceProvider)
                                }
                                val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA // Using front camera as per your last request

                                val imageAnalysis = ImageAnalysis.Builder()
                                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                    .build()
                                    .also { it.setAnalyzer(Executors.newSingleThreadExecutor(), qrCodeAnalyzer) }

                                try {
                                    cameraProvider.unbindAll()
                                    cameraProvider.bindToLifecycle(lifecycleOwner, cameraSelector, preview, imageAnalysis)
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }, ContextCompat.getMainExecutor(ctx))
                            previewView
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Camera permission is required.", color = Color.White, textAlign = TextAlign.Center)
                    }
                }
            }
        }

        // Functional "Back" button at the bottom
        Button(
            onClick = { navController.popBackStack() },
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xffd9d9d9).copy(alpha = 0.5f)),
            border = BorderStroke(2.dp, Color.Black)
        ) {
            Text("BACK", color = Color.White)
        }

        // --- OVERLAYS for Success/Error (No changes needed) ---
        scanResult?.let {
            if (it == "Success") {
                OverlayBox(text = "Return Successful!") {
                    navController.popBackStack() // Go back to the return list
                }
            } else if (it == "Error") {
                OverlayBox(text = "Wrong book scanned!") {
                    scanResult = null // Allow scanning again
                    qrCodeAnalyzer.resumeScanning()
                }
            }
        }
    }
}

// QrCodeAnalyzer is already defined in your other scanner screen, so we don't need to redefine it
// unless this file is completely separate. For simplicity, I've left the definition in the other file.
// If you get an "Unresolved reference" for QrCodeAnalyzer, you need to move it to a shared file.

// The OverlayBox is also likely defined elsewhere, so it doesn't need to be repeated.
// If you get an "Unresolved reference" for OverlayBox, move it to a shared file.
