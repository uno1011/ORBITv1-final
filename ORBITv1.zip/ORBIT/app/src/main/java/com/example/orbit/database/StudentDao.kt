package com.example.orbit.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface StudentDao {

    @Query("SELECT * FROM students")
    suspend fun getAllStudents(): List<Student>

    @Query("SELECT * FROM students WHERE studentNumber = :number LIMIT 1")
    suspend fun getStudentByNumber(number: String): Student?

    @Query("SELECT * FROM students WHERE lrn = :lrn LIMIT 1")
    suspend fun getStudentByLrn(lrn: String): Student?

    @Query("SELECT * FROM students WHERE contactNumber = :phoneNumber LIMIT 1")
    suspend fun getStudentByPhoneNumber(phoneNumber: String): Student?

    @Query("SELECT count(*) FROM students")
    suspend fun countStudents(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(student: Student)
}
