package com.example.orbit.activities

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.orbit.database.AppDatabase
import com.example.orbit.database.Student
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun SignUpScreen(navController: NavController) {
    var name by remember { mutableStateOf(TextFieldValue("")) }
    var lrn by remember { mutableStateOf(TextFieldValue("")) }
    var contactNumber by remember { mutableStateOf(TextFieldValue("")) }
    var school by remember { mutableStateOf(TextFieldValue("")) } // New state for school

    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val db = remember { AppDatabase.getDatabase(context) }
    var newStudentNumberToNavigate by remember { mutableStateOf<String?>(null) }

    val smsPermissionState = rememberPermissionState(Manifest.permission.SEND_SMS)

    LaunchedEffect(key1 = true) {
        smsPermissionState.launchPermissionRequest()
    }

    LaunchedEffect(newStudentNumberToNavigate) {
        newStudentNumberToNavigate?.let { number ->
            navController.navigate("studentNumber/$number")
            newStudentNumberToNavigate = null
        }
    }

    val isLrnValid by remember { derivedStateOf { lrn.text.length == 12 && lrn.text.all { it.isDigit() } } }
    val isContactNumberValid by remember { derivedStateOf { contactNumber.text.length == 11 && contactNumber.text.all { it.isDigit() } && contactNumber.text.startsWith("09") } }
    val isNameValid by remember { derivedStateOf { name.text.isNotBlank() } }
    val isSchoolValid by remember { derivedStateOf { school.text == "znnhst" } } // Validation for school
    val isFormValid by remember { derivedStateOf { isLrnValid && isContactNumberValid && isNameValid && isSchoolValid } }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xff477876), Color(0xff3d4d75), Color(0xff192239)),
                    center = Offset(193.13f, 653.65f),
                    radius = 1121.95f
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 64.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Text(text = "ORBIT", color = Color.White, style = MaterialTheme.typography.displayLarge)
            Spacer(modifier = Modifier.height(32.dp))
            Text(text = "SIGN UP", color = Color(0xffa4b2eb), style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(24.dp))

            StyledTextField(value = name, onValueChange = { name = it }, label = "Full Name", isError = name.text.isNotBlank() && !isNameValid)
            Spacer(modifier = Modifier.height(16.dp))
            StyledTextField(value = lrn, onValueChange = { lrn = it }, label = "LRN", isError = lrn.text.isNotBlank() && !isLrnValid)
            Spacer(modifier = Modifier.height(16.dp))
            StyledTextField(value = contactNumber, onValueChange = { contactNumber = it }, label = "Contact Number", isError = contactNumber.text.isNotBlank() && !isContactNumberValid)
            Spacer(modifier = Modifier.height(16.dp))
            StyledTextField(value = school, onValueChange = { school = it }, label = "What school are you in?", isError = school.text.isNotBlank() && !isSchoolValid)

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = {
                    if (!smsPermissionState.status.isGranted) {
                        Toast.makeText(context, "SMS permission is required to sign up.", Toast.LENGTH_LONG).show()
                        smsPermissionState.launchPermissionRequest()
                        return@Button
                    }
                    scope.launch(Dispatchers.IO) {
                        val studentCount = db.studentDao().countStudents()
                        val newStudentNumber = (studentCount + 1).toString().padStart(4, '0')
                        val newStudent = Student(
                            studentNumber = newStudentNumber,
                            name = name.text,
                            lrn = lrn.text,
                            contactNumber = contactNumber.text,
                            school = school.text
                        )
                        db.studentDao().insert(newStudent)

                        sendWelcomeSms(context, contactNumber.text, name.text, newStudentNumber)

                        newStudentNumberToNavigate = newStudentNumber
                    }
                },
                enabled = isFormValid,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xff78008b)),
                border = BorderStroke(2.dp, Color.Black)
            ) {
                Text("ENTER", fontSize = 24.sp, modifier = Modifier.padding(horizontal = 32.dp))
            }
        }

        Button(
            onClick = { navController.popBackStack() },
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xffd9d9d9).copy(alpha = 0.5f)),
            border = BorderStroke(2.dp, Color.Black)
        ) {
            Text("BACK", color = Color.White)
        }
    }
}

private fun sendWelcomeSms(context: Context, phoneNumber: String, studentName: String, studentNumber: String) {
    try {
        val message = "Welcome to ORBIT, $studentName! Your new student number is $studentNumber. You can now use this to log in."
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:$phoneNumber")
            putExtra("sms_body", message)
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    } catch (e: Exception) {
        (context as? Activity)?.runOnUiThread {
            Toast.makeText(context, "Could not open messaging app.", Toast.LENGTH_LONG).show()
        }
        e.printStackTrace()
    }
}

@Composable
private fun StyledTextField(value: TextFieldValue, onValueChange: (TextFieldValue) -> Unit, label: String, isError: Boolean) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, color = Color(0xffa7a2a2)) },
        singleLine = true,
        isError = isError,
        shape = RoundedCornerShape(15.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color(0xff1b2e5d),
            unfocusedBorderColor = Color(0xff1b2e5d),
            errorBorderColor = Color.Red,
            focusedTextColor = Color.Black,
            unfocusedTextColor = Color.Black,
            cursorColor = Color.Black,
            focusedContainerColor = Color.White,
            unfocusedContainerColor = Color.White
        ),
        modifier = Modifier
            .width(512.dp)
            .border(
                width = 2.dp,
                color = if (isError) Color.Red else Color(0xff1b2e5d),
                shape = RoundedCornerShape(15.dp)
            )
    )
}
