package com.example.orbit.activities

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.orbit.ui.theme.ORBITTheme

/**
 * This is the "dumb" design component. It only knows how to draw the UI for the auth choice screen.
 * It receives click actions from the "smart" composable that calls it.
 */
@Composable
fun AuthChoiceScreenDesign(
    modifier: Modifier = Modifier,
    onLoginClick: () -> Unit,
    onSignUpClick: () -> Unit,
    onBackClick: () -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xff477876), Color(0xff3d4d75), Color(0xff192239)),
                    center = Offset(193.13f, 653.65f),
                    radius = 1121.95f
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 64.dp), // Add padding from the top
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top // Align content to the top
        ) {
            Text(
                text = "ORBIT",

                color = Color.White,
                style = MaterialTheme.typography.displayLarge
            )

            Text(
                text = "Offline Research  Book Information Tracker",
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 32.dp),
                style = MaterialTheme.typography.headlineLarge
            )

            Spacer(modifier = Modifier.height(100.dp))

            Text(
                text = "HELLO USER!",
                color = Color(0xffa4b2eb),
                style = MaterialTheme.typography.headlineMedium
            )

            Spacer(modifier = Modifier.height(48.dp))

            // "LOG IN" Button
            AuthButton(
                text = "LOG IN",
                onClick = onLoginClick // Use the passed-in click action
            )

            Spacer(modifier = Modifier.height(24.dp))

            // "SIGN UP" BUTTON
            AuthButton(
                text = "SIGN UP",
                onClick = onSignUpClick // Use the passed-in click action
            )
        }

        // "BACK" BUTTON
        Button(
            onClick = onBackClick, // Use the passed-in click action
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xffd9d9d9).copy(alpha = 0.5f)),
            border = BorderStroke(2.dp, Color.Black)
        ) {
            Text("BACK", color = Color.White)
        }
    }
}

// A reusable, styled button for this screen
@Composable
private fun AuthButton(text: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .width(180.dp)
            .height(53.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(color = Color(0xFFD9D9D9).copy(alpha = 0.5f))
            .border(
                border = BorderStroke(2.dp, Color.Black),
                shape = RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color.White,
            style = MaterialTheme.typography.labelLarge
        )
    }
}


@Preview(showBackground = true, widthDp = 1280, heightDp = 800)
@Composable
private fun AuthChoiceScreenDesignPreview() {
    ORBITTheme {
        AuthChoiceScreenDesign(
            onLoginClick = {},
            onSignUpClick = {},
            onBackClick = {}
        )
    }
}
