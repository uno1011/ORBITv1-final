package com.example.orbit.activities

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.orbit.database.AppDatabase
import com.example.orbit.database.Book
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun BookDetailsScreen(navController: NavController, isbn: String) {
    val context = LocalContext.current
    val db = remember { AppDatabase.getDatabase(context) }
    var book by remember { mutableStateOf<Book?>(null) }
    var isProcessing by remember { mutableStateOf(false) } // State for processing
    val scope = rememberCoroutineScope()

    LaunchedEffect(key1 = isbn) {
        withContext(Dispatchers.IO) {
            book = db.bookDao().getBookByIsbn(isbn)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (book != null) {
            Text(text = book!!.title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "by ${book!!.author}", style = MaterialTheme.typography.bodyLarge)
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "Category: ${book!!.category}", style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(24.dp))

            // Updated availability logic
            when {
                isProcessing -> {
                    Text(text = "Status: Processing...", color = Color.Gray, fontSize = 18.sp)
                }
                book!!.availability -> {
                    Text(text = "Status: Available", color = Color(0xFF008000), fontSize = 18.sp)
                }
                else -> {
                    Text(text = "Status: Not Available", color = Color.Red, fontSize = 18.sp)
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = {
                    isProcessing = true // Set processing to true immediately
                    scope.launch(Dispatchers.IO) {
                        val updatedBook = book!!.copy(availability = false)
                        db.bookDao().update(updatedBook)
                        withContext(Dispatchers.Main) {
                            book = updatedBook
                            isProcessing = false // Reset after update
                        }
                    }
                },
                enabled = book!!.availability && !isProcessing // Disable if not available or already processing
            ) {
                Text("Borrow This Book")
            }

        } else {
            Text("Searching for book...")
            Spacer(modifier = Modifier.height(16.dp))
            CircularProgressIndicator()
        }

        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = { navController.popBackStack() }) {
            Text("Back")
        }
    }
}
