package com.example.orbit.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

@Database(entities = [Student::class, Book::class, Transaction::class], version = 4, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun studentDao(): StudentDao
    abstract fun bookDao(): BookDao
    abstract fun transactionDao(): TransactionDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        // Migration from version 3 to 4 to add 'school' column
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE students ADD COLUMN school TEXT")
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "orbit_database"
                )
                .addMigrations(MIGRATION_3_4) // Added migration
                .addCallback(AppDatabaseCallback(context))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AppDatabaseCallback(
        private val context: Context
    ) : Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            CoroutineScope(SupervisorJob()).launch(Dispatchers.IO) {
                val database = getDatabase(context)
                val studentDao = database.studentDao()
                val bookDao = database.bookDao()

                // Pre-populate the database on creation (updated with school field)
                studentDao.insert(Student(studentNumber = "001", name = "Test Student", lrn ="123456789012", contactNumber = "09123456789", school = "ZNNHS-T"))
                
                // ... (rest of the pre-population logic remains the same)
                bookDao.insert(Book(isbn = "978-0321765723", title = "The C++ Programming Language", author = "Bjarne Stroustrup", year = 2013, category = "Programming", availability = true))
                bookDao.insert(Book(isbn = "0027", title = "ORGANIC MIXTURE FOR SOIL ENRICHMENT IN THE GROWTH OF TOMATO (Solanum lycopersicum) PLANT", author = "MECKIAN BELLE B. CABILIN", year = 2024, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0001", title = "SEK FERTILIZER: ITS EFFECT ON THE INITIAL GROWTH OF MUNG BEANS(Vigna radiata) PLANT", author = "DOMINIQUE P. ALISTADO", year = 2017, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0002", title = "ORGANIC FOOD SCRAPS FOR SOIL FERTILITY", author = "FRANZ HARMON A. GENOBATEN, ARIELLE DENISE B. VARON, PAUL MARX T. ALPUERTO", year = 2018, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0003", title = "THE ANTIMICROBIAL PROPERTY OF GARLIC (Allium sativum) BULB EXTRACT AND ITS EFFECT AS BIO PRESERVATIVE TO PORK MEAT", author = "JELENA SHELBY A. LIM", year = 2018, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0004", title = "THE ANTIMICROBIAL PROPERTY OF GARLIC (Allium sativum) BULB EXTRACT AND ITS EFFECT AS BIO PRESERVATIVE TO PORK MEAT", author = "JELENA SHELBY A. LIM", year = 2018, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0005", title = "ANTIBACTERIAL PROPERTY OF DWARF SANTAN (Ixora coccinea) ROOT DECOCTION", author = "FRANCHEZKA MAREE O. ZAPANTA, ERIKA MAE M. BUSTALINO, ALEXAN DRA P. PANOY", year = 2018, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0006", title = "ANTIBACTERIAL PROPERTY OF DWARF SANTAN (Ixora coccinea) ROOT DECOCTION", author = "FRANCHEZKA MAREE O. ZAPANTA, ERIKA MAE M. BUSTALINO, ALEXAN DRA P. PANOY", year = 2018, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0007", title = "KAMIAS (Averrhoa bilimbi) EXTRACT AS PRESERVATIVE TO FISH", author = "ADELPHE CHARIS D. CATAPAN, JFLER LEGA JOY L. MINDORO, FRETCHELL A. MONTES", year = 2018, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0008", title = "KAMIAS (Averrhoa bilimbi) EXTRACT AS PRESERVATIVE TO FISH", author = "ADELPHE CHARIS D. CATAPAN, JFLER LEGA JOY L. MINDORO, FRETCHELL A. MONTES", year = 2018, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0009", title = "COMPOSTED RABBITS' MANURE WITH SAWDUST AND CRUSHED CRABSHELLS AS ALTERNATIVE FERTILIZER ON PECHAY (Brassica rapa)", author = "DENVER GIL E. TAGAB, J'RAM G. BARBASO, REXCEL P. ABILA", year = 2018, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0010", title = "MADRE DE CACAO (Gliricidia sepium) AND PAPAYA (Carica papaya) LEAF EXTRACT AS ALTERNATIVE LARVICIDE", author = "MARY CLAIRE A. HAMILTON, ANGEL MARIE B. CANIZAR, XANTHIA LOU F. GACES", year = 2018, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0011", title = "DECOMPOSED SABA BANANA (Musa acuminata) PEELINGS AND CRUSHED EGGSHELLS AS ALTERNATIVE ORGANIC FERTILIZER TO PECHAY PLANT (Brassica rapa)", author = "KIARA KEZIAH M. MIRA", year = 2018, category = "LIFE SCIENCEE", availability = true))
                bookDao.insert(Book(isbn = "0012", title = "ANTIBACTERIAL PROPERTIES OF HANDIIB-ON (Blumea balsamifera), LAGUNDI (Vitex negundo), and OREGANO (Origanum vulgare) LEAVES EXTRACT", author = "CHARLES MIGUEL R. JOMAWAS, JULIA TRISHA J. FERNANDEZ, ERWIN V. RAMENTO, JERELYN P. TAPAY", year = 2018, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0013", title = "\"DRIED COW (Bos taurus) MANURE AND OYSTER (Crassostrea gigas) SHELL POWDER AS ORGANIC FERTILIZER FOR BELL PEPPER (Capsicum annum) PLANT\"", author = "VINCE THERESE P. GUIMBARDA, JELICA J. MORANDARTE, FEBY DANE T. MALUTO, BRIGETTE T. PIZON", year = 2019, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0014", title = "ANTIMICROBIAL PROPERTY OF BIASONG (Citrus Micrantha) EXTRACT AND ITS EFFECT AS BIO PRESERVATIVE TO BEEF, CHICKEN, FISH AND PORK MEAT", author = "AUBREY KLYLE E. CABANLIT", year = 2019, category = "", availability = true))
                bookDao.insert(Book(isbn = "0015", title = "ANTIBACTERIAL PROPERTIES OF OREGANO (Origanum vulgare) LEAVES DECOCTION AND CALAMANSI (Citrofortunella microcarpa) PULP EXTRACT AGAINST COUGH CAUSING BACTERIA", author = "LUIS VINCENT LOCULAN JR., KRISTELLE ACE NAVARRO, KRISTINE JEWEL MACUTE, KEON KIM ADARO", year = 2019, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0016", title = "MALUNGGAY (Moringa oleifera) STALK AND COW (Bos taurus) BONE MEAL AS ALTERNATIVE FERTILIZER TO TOMATO PLANT (Solanum lycopersicum)", author = "LEMUEL MATTHEW B. ELUMBA, JON HENDRIK B. VERGARA, ALTHEA GAY S. TABANAG, HONEY KYLLA P. PANONG, RUDZ CULLIN T. GARCIA, MELANIE M. SORRONDA", year = 2020, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0017", title = "ANTIBACTERIAL PROPERTY OF TUBA-TUBA (Jatropha curcas) LEAVES DECOCTION", author = "TRISHA ANGELICA D. CABRERA, GODTHEA ANN O. CONDE, JAN ULRICH V. CALIBO, MARICAR O. LUNJAS, ALLEAH M. MUIT", year = 2020, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0018", title = "ANTIBACTERIAL PROPERTY OF TUBA-TUBA (Jatropha curcas) LEAVES DECOTION", author = "TRISHA ANGELICA D. CABRERA, GODTHEA ANN O. CONDE, JAN ULRICH V. CALIBO, MARICAR O. LUNJAS, ALLEAH M. MUIT", year = 2020, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0019", title = "LARVICIDAL ACTIVITY OF NEEM (Azadirachta indica) LEAVES EXTRACT", author = "NINA NICOLE S. VILLADAREZ, KEREN MICHELLE M. MIRA, MARC ROLANDO T. ORONG, JAKE H. BAJO", year = 2020, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0020", title = "CYTOTOXICITY OF ROSY PERIWINKLE (Carbaranthus roseus) CRUDE EXTRACT ON ONION (Allium cepa) ROOT TIP CELLS", author = "RHYCA YLLAH P. VILLANUEVA", year = 2020, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0021", title = "CYTOTOXICITY OF ROSY PERIWINKLE (Carbaranthus roseus) CRUDE EXTRACT ON ONION (Allium cepa) ROOT TIP CELLS", author = "RHYCA YLLAH P. VILLANUEVA", year = 2020, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0022", title = "FERMENTED COCONUT (Cocos nucifera L.) WATER AND EGGSHELLS AS ALTERNATIVE HERBICIDE ON CARABAO GRASS (Paspalum conjugatum)", author = "VEA ALESSANDRA G. CONCHA, MARY XZENEAL G. PARAMA, JC B. CANOY, PRINCESS GIANE B. GALLON, MAEGAN KATE T. LANOJAN", year = 2024, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0023", title = "FERMENTED PINEAPPLE PEELINGS (Ananas comosus) EXTRACTS AS AN ORGANIC WEED HERBICIDE", author = "ROSIE MAE LOU Q. OQUIZ, NHEL ADRIAN B. PONDOC, CHARLYAN TRIXY A. PIZON, DARISSE B. MACALAT, SHANE KRISHA M. TABEFRANCA, JOEBETH ANNE F. BUHISAN", year = 2024, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0024", title = "KURYENTANOM: PERFORMANCE EVALUATION OF BIOELECTRICITY GENERATION FROM CHINESE EVERGREEN (Aglaonema commutatum)", author = "KIARRA LEE HYACINTH P. CARREON, LARA L. CARBON", year = 2022, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0025", title = "\"KANGKONG (Ipomoea aquatica) AND CHINESE PECHAY (Brassica rapa subsp Pekinensis) WITH CHILI (Capsicum annuum) AS ALTERNATIVE FEED FOR BROILER CHICKEN (Gallus gallus domesticus)\"", author = "SHARMAE J. PACULANANG", year = 2018, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0026", title = "LARVICIDAL EFFECT OF ONION (Allium cepa) AND GARLIC (Allium sativum) EXTRACTS AGAINST MOSQUITO WRIGGLERS", author = "CHRISTINE BERNA E. CELICIOUS, JAROLD ADRIAN V. ENDEREZ, VINCENT JAY D. ENRIQUEZ, LANCE ROBIN L. KYAMKO", year = 2019, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0027", title = "ORGANIC MIXTURE FOR SOIL ENRICHMENT IN THE GROWTH OF TOMATO (Solanum lycopersicum) PLANT", author = "MECKIAN BELLE B. CABILIN", year = 2024, category = "LIFE SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0028", title = "GROUNDNUT(Arachis hypogaea) HUSK FIBERS AS AN ALTERNATIVE WRITING PAPER", author = "TRESHIA MAE D. BANAWAN", year = 2020, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0029", title = "GROUNDNUT(Arachis hypogaea) HUSK FIBERS AS AN ALTERNATIVE WRITING PAPER", author = "TRESHIA MAE D. BANAWAN", year = 2020, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0030", title = "GEMELINA(gmelinaarborea) FRUIT EXTRACT AS ALTERNATIVE MOSQUITO LARVICIDE", author = "ANDREA GALE C. SINCONIEGUE, GERMANIE PHIL V. HERRERA, MABEL S. DUHAYLUNGSOD, CYRIL WIN I. MACARUAL, ARNEE H. DENGAL, RUTH U. PACUYAO", year = 2020, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0031", title = "GEMELINA(gmelinaarborea) FRUIT EXTRACT AS ALTERNATIVE MOSQUITO LARVICIDE", author = "ANDREA GALE C. SINCONIEGUE, GERMANIE PHIL V. HERRERA, MABEL S. DUHAYLUNGSOD, CYRIL WIN I. MACARUAL, ARNEE H. DENGAL, RUTH U. PACUYAO", year = 2020, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0032", title = "GINGER(Zingiber offcinale) LEAVES EXTRACT AND ITS EFFECT AS NATURAL PRESERVATIVE TO CHICKEN MEAT", author = "AIDAN NATHANIEL T. BUSTALIÑO, JUSTINE SILVERRY ALICANTE, KATE NATHALIE D. LUCE, HESRT M. EUHENGCO, LUIGI M. VILLEJO", year = 2020, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0033", title = "GINGER(Zingiber offcinale) LEAVES EXTRACT AND ITS EFFECT AS NATURAL PRESERVATIVE TO CHICKEN MEAT", author = "AIDAN NATHANIEL T. BUSTALIÑO, JUSTINE SILVERRY ALICANTE, KATE NATHALIE D. LUCE, HESRT M. EUHENGCO, LUIGI M. VILLEJO", year = 2020, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0034", title = "LOW-DENSITY POLYETHYLENE PLASTIC BAGS AND MAHOGANY(Swietnia macrophylla) CARPEL AS ALTERNATIVE COMPONENTS FOR PARTICLE BOARD", author = "FRANCHESKA ISOBELLA T. BRILLANTES, CHRISTIAN GABRIEL, U. DELA CRUZ, DIANNE CLAIRE MARIE B. TAGAB, MAUREEN JOYCE N. DANO, MARY JEZEL A. VILLAVER", year = 2020, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0035", title = "ALITAPTAP: EVALUATION OF THE PERFORMANCE OF THE PORTABLE DUCTED WIND TURBINE", author = "DELFIN MATTHEW C. LEE, ANDRE GEOMAN N.GEOGRAFO, AIRON CHRISTIAN EARL Q. ACOPIADO", year = 2022, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0036", title = "EGG-NIYOG: PARTIAL SUBSTITUTION OF EGGSHELL POWDER IN CEMENT AND COCONUT(Cocos nucifera) PEAR ON FINE AGGREGATES IN THE CREATION OF CONCRETE BLOCKS", author = "ZIPPORAH REEANGLEA P. MONDEJAR, SHEREE NICOLE G. YBAÑEZ, RHEA MARIE O. STA. ANA", year = 2022, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0037", title = "COCONUT(Cocos nucifera) COIR AS MAIN COMPONENT IN MAKING PACKAGING PAPER", author = "SYVILLE L. MACATUAL, SHIENA MAY T. SABANAL, RAPHAEL FRUCTUOSO B. LUGA, JASDEE C. ALVAREZ, DANIKA ESTELLE J. BAYRON", year = 2024, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0038", title = "METAL BOTTLE CAPS, COCONUT MESOCARP AND RICE STRAW AS PARTICLE BOARD COMPONENTS", author = "KIRSTEN CAFFERINA AERIANNE B. MEDIAMAR, KATHLEEN NIKKA B. CAPUNDAG, RAIZZA JANE L. DUMALAY, JEANIZ BELLE P. CALUNIA, CHRISTER G. BORALO", year = 2024, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0039", title = "RICE HUSK(Oryza sativa) ASH AND FLY ASH AS AGGREGATES IN MAKING HOLLOW BLOCKS", author = "CHEERIE MAE Y. TURTOGO, SHADRACH ALBERT A. BIOLANGO, REIKEN B. CALAMBA, JAICA MARIE C. SALONOY, RANAH GIANE B. BACATAN, EDEL JOHN P. ACBAYAN", year = 2024, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0040", title = "RePa-CoFis: CORN(Zea mays) FIBERS AS AN ADDITIVE TO RECYCLED PAPER BAGS", author = "FRACES SOPHIA T. BRILLANTES, BEATRIZ KYNDRA C. FEROLINO, NAYAH CIOTHEA B. BARRERA, PROX SANTINO A. BALBUENA", year = 2024, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0041", title = "BANANA(Musa acuminata) PEELINGS AS CARDBOARD COMPONENT", author = "ROZYTTE GALR C. IMPERIAL, ASHLEY IRE C. ELUMBA, SHANNEN T. GARCIA", year = 2018, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0042", title = "TIESA(Pouteria campechiana) AS KULFI", author = "ZILLAH CLITIANNE B. VIRTUDAZO, JHON RALPH VENECER H. TERCIO, JONATHAN ISRAEL R. GELOGO", year = 2018, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0043", title = "FEASIBILITY RICE HULLS AND RHA AS TABLETOP", author = "MA. ANGELA I. HAICTIN, JEA GRACE P. BAROY, JESSA P. GEMPEROSO", year = 2015, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0044", title = "FEASIBILITY OF UTOT-UTOT (Lantana camara) FLOWER AND LEAF EXTRACT AS AN AIR FRESHENER", author = "MANUELLE GRACE NICA S. OMAMALIN, JF PRINCESS NIKOLE L. SAGUIN, HARRY P. MANOGURA JR", year = 2016, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0045", title = "BANANA(Musa acuminata) STEM FIBER AS ALTERNATIVE THREAD", author = "JEAN MARIE C. CANETE, NINA KEITH U. OGOC, KEANU L. DULFO", year = 2018, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0046", title = "PRODUCTION AND EVALUATION OF FLOUR FROM NIPA (Nypa fruticans) NUT", author = "MARY ANGELIQUE B. CAGUINDANGAN, SHIPHRAH MARIAN C. FLORES, ELEXI KAE V. ELUMBA", year = 2016, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0047", title = "BOTTLEBRUSH(Callistemon viminalis) LEAVES AS ALTERNATIVE MOSQUITO COIL", author = "APOLLO JUNE JULAPONG, FELIZ MARIE V. PULANCO, JOSE LUKAS F. AUDITOR", year = 2018, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0048", title = "MALUNGGAY(Moringa oleifera) LEAVES EXTRACT WITH BAKING SODA AS AN ALTERNATIVE TILE CLEANING AGENT", author = "COLEEN CLAIRE S. CLAUDIO, PRINCESS KATE V. MANABIT, JELIAN STEPHANIE A. LIM", year = 2017, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0049", title = "UTILIZATION OF BANANA(Musa sapientum, Musa acuminata, Musa balbisiana) PEELS AS GROUNDWATER PURIFIER", author = "SHEREE MARGARETTE G. CRISOSTOMO", year = 2019, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0050", title = "GUAVA (Psidium guajava) LEAVES EXTRACT AS ADDITIVE TO SHAMPOO", author = "SAMANTHA ADRIANA S. AMATONG, KIMBERLY JANE L. LAZONA, JERIC S. INTE", year = 2018, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0051", title = "CHILE PEPPER(Capsicum frutescens) FRUIT EXTRACT AS BIO-PESTICIDE FOR TERMITE CONTROL", author = "KOLAI D. AGUSTIN, JANINA ANYA YSOBEL I. TANIEGRA, LYKA ANNE JEL B. DAYONOT, JERICKA NICOLE S. INTE, JOHN FRED S. SAILES, LEIANNA V.  PARIÑAS", year = 2019, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0052", title = "KAMIAS (Averrhoa balimbi) FRUIT EXTRACT AS ALTERNATIVE STAIN REMOVER", author = "KEANU LANZ C. GUERRA", year = 2018, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0053", title = "FEASIBILITY OF MALUNGGAY (Moringa oleifera) SEEDS AS ALTERNATIVE COFFEE", author = "GABRIELLE AÑA G. ASPRER, PHEA MARIE A. JAMOLOD, KENDRA FAITH F. DAYRIT", year = 2018, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0054", title = "WOOD SHAVING CHARCOAL FROM COCONUT TRUNK(Cocos Nucifera) AS ALTERNATIVE INK REFILL FOR PERMANENT MARKER", author = "MICAH PAULINE F. CADUNGOG, GERRY JET S. GUBANTES, JADE M. REDILLAS", year = 2018, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0055", title = "ANTIBACTERIAL PROPERTY OF TUBA-TUBA (Jatropha curcas) LEAVES DECOTION", author = "TRISHA ANGELICA D. CABRERA, GODTHEA ANN O. CONDE, JAN ULRICH V. CALIBO, MARICAR O. LUNJAS, ALLEAH M. MUIT", year = 2020, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0056", title = "ANTIBACTERIAL PROPERTY OF TUBA-TUBA (Jatropha curcas) LEAVES DECOTION", author = "TRISHA ANGELICA D. CABRERA, GODTHEA ANN O. CONDE, JAN ULRICH V. CALIBO, MARICAR O. LUNJAS, ALLEAH M. MUIT", year = 2020, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0057", title = "RICE (Oryza sativa) HUSK AS ALTERNATIVE COMPONENT FOR FIREBOARD", author = "SOL YLYCYL G. MORANDARTE", year = 2020, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0058", title = "RICE (Oryza sativa) HUSK AS ALTERNATIVE COMPONENT FOR FIREBOARD", author = "SOL YLYCYL G. MORANDARTE", year = 2020, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0059", title = "GINGER RHIZOME (Zingiber officinale) AND CHILI PEPPER (Capsicum annuum) FRUIT PODS EXTRACT AS BOTANICAL LARVICIDE FOR MOSQUITO CONTROL", author = "MA. RENJAYE GAYLE M. BENITEZ, ALTHEA MAE M. GOMERA, VANESSA MAE A. SASO, KYLLE N. BASTASA", year = 2019, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0060", title = "VOLTAGE PRODUCED BY WET AND DRY CHICKEN MANURE", author = "JOJENE IAN BRYLLE M. LOCSIN, NIÑO MICOLE C. OMAGUING", year = 2020, category = "PHYSICAL SCI", availability = true))
                bookDao.insert(Book(isbn = "0061", title = "ARDUINO-BASED WASTE COLLECTION AND SEGREGATOR AUTOMATION", author = "JHOELLE MARGARETTE M. RUBI, PRINCESS DAWN C. SALAVERIA, KAY FRANCINE G. ONGSUCO, DARA R. CASTILLON, ANGEL FAITH P. ERE", year = 2024, category = "ROBOTICS", availability = true))
                bookDao.insert(Book(isbn = "0062", title = "GROUNDNUT(Arachis hypogaea) HUSK FIBERS AS AN ALTERNATIVE WRITING PAPER", author = "TRESHA MAE D. BANAWAN", year = 2020, category = "PHYSICAL SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0063", title = "POLYETHYLENE TEREPHTHALATE AS ADDITIVE IN RICE (Oryza sativa) HUSK ASH-MODIFIED BITUMEN IN ASPHALT", author = "MAECI GWEN V. ACEBES, KATE ZARA J. BERO", year = 2024, category = "PHYSICAL SCIENCE", availability = true))
                bookDao.insert(Book(isbn = "0064", title = "ORGANIC FOOD SCRAPS FOR SOIL FERTILITY", author = "FRANZ HARMON A. GENOBATEN, ARIELLE DENISE B. VARON, PAUL MARX T. ALPUERTO", year = 2018, category = "LIFE SCIENCE", availability = true))
            }
        }
    }
}
