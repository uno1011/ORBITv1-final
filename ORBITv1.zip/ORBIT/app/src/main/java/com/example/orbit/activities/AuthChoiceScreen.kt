package com.example.orbit.activities

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavController

/**
 * This is the "smart" composable.
 * It knows about navigation and tells the design what to do when buttons are clicked.
 */
@Composable
fun AuthChoiceScreen(navController: NavController, modifier: Modifier = Modifier) {
    // This now passes lambdas for each click action instead of the whole NavController.
    // This resolves the error and is better for your code structure.
    AuthChoiceScreenDesign(
        modifier = modifier,
        onLoginClick = { navController.navigate("login") },
        onSignUpClick = { navController.navigate("signup") },
        onBackClick = { navController.popBackStack() }
    )
}
