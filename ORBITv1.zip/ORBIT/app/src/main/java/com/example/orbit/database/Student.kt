package com.example.orbit.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "students")
data class Student(
    @PrimaryKey val studentNumber: String,
    val name: String,
    val lrn: String,
    val contactNumber: String,
    val school: String? = null // Made nullable with a default value for safety
)
