package com.example.orbit.activities

import android.Manifest
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.orbit.database.AppDatabase
import com.example.orbit.database.Book
import com.example.orbit.database.Student
import com.example.orbit.database.Transaction
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class EnrichedTransaction(
    val transaction: Transaction,
    val book: Book?,
    val student: Student?
)

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun AdminDashboardScreen(navController: NavController) {
    val context = LocalContext.current
    val db = remember { AppDatabase.getDatabase(context) }
    var enrichedTransactions by remember { mutableStateOf<List<EnrichedTransaction>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    val smsPermissionState = rememberPermissionState(Manifest.permission.SEND_SMS)

    LaunchedEffect(key1 = Unit) {
        if (!smsPermissionState.status.isGranted) {
            smsPermissionState.launchPermissionRequest()
        }

        withContext(Dispatchers.IO) {
            val transactions = db.transactionDao().getAllTransactions()
            val enriched = transactions.map {
                EnrichedTransaction(
                    transaction = it,
                    book = db.bookDao().getBookByIsbn(it.bookIsbn),
                    student = db.studentDao().getStudentByNumber(it.studentNumber)
                )
            }
            enrichedTransactions = enriched.sortedByDescending { it.transaction.dateBorrowed }
            isLoading = false
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xff477876), Color(0xff3d4d75), Color(0xff192239)),
                    center = Offset(193.13f, 653.65f),
                    radius = 1121.95f
                )
            )
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "DATABASE",
                color = Color(0xffa4b2eb),
                fontSize = 80.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 40.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (smsPermissionState.status.isGranted) "SMS Reminders: Active" else "SMS Permission Required",
                color = if (smsPermissionState.status.isGranted) Color.Green else Color.Yellow,
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(16.dp))

            if (isLoading) {
                CircularProgressIndicator(modifier = Modifier.padding(top = 100.dp))
            } else if (enrichedTransactions.isEmpty()) {
                Text("No transactions found.", color = Color.White, modifier = Modifier.padding(top = 100.dp))
            } else {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                    HeaderCell("TITLE", 2f, Color.White)
                    HeaderCell("STUDENT", 1.5f, Color.White)
                    HeaderCell("BORROWED", 1f, Color.White)
                    HeaderCell("DUE DATE", 1f, Color.White)
                    HeaderCell("RETURNED", 1f, Color.White)
                }
                Divider(color = Color.White.copy(alpha = 0.5f))

                LazyColumn(modifier = Modifier.padding(horizontal = 8.dp).weight(1f)) {
                    items(enrichedTransactions) { item ->
                        val isOverdue = System.currentTimeMillis() > item.transaction.dateToBeReturned && item.transaction.dateReturned == null
                        val dueDateColor = if (isOverdue) Color.Red else Color.White

                        Row(Modifier.fillMaxWidth()) {
                            DataCell(item.book?.title ?: "Unknown", 2f, Color.White)
                            DataCell(item.student?.name ?: "Unknown", 1.5f, Color.White)
                            DataCell(formatDate(item.transaction.dateBorrowed), 1f, Color.White)
                            DataCell(formatDate(item.transaction.dateToBeReturned), 1f, dueDateColor)
                            DataCell(item.transaction.dateReturned?.let { formatDate(it) } ?: "-", 1f, Color.White)
                        }
                        Divider(color = Color.White.copy(alpha = 0.3f))
                    }
                }
            }
        }

        Button(
            onClick = { navController.popBackStack() },
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xffd9d9d9).copy(alpha = 0.5f))
        ) {
            Text("BACK", color = Color.White)
        }
    }
}

@Composable
fun RowScope.HeaderCell(text: String, weight: Float, color: Color) {
    Text(
        text = text,
        modifier = Modifier
            .weight(weight)
            .padding(8.dp),
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center,
        color = color,
        fontSize = 12.sp
    )
}

@Composable
fun RowScope.DataCell(text: String, weight: Float, color: Color, modifier: Modifier = Modifier) {
    Text(
        text = text,
        modifier = modifier
            .weight(weight)
            .padding(8.dp),
        textAlign = TextAlign.Center,
        color = color,
        fontSize = 12.sp
    )
}

private fun formatDate(timestamp: Long): String {
    val sdf = SimpleDateFormat("MM/dd", Locale.US)
    return sdf.format(Date(timestamp))
}
