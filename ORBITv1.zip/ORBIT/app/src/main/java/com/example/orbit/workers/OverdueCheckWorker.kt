package com.example.orbit.workers

import android.content.Context
import android.telephony.SmsManager
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.orbit.database.AppDatabase

class OverdueCheckWorker(appContext: Context, workerParams: WorkerParameters) :
    CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        Log.d("OverdueCheckWorker", "Fully automated background check started...")

        val database = AppDatabase.getDatabase(applicationContext)
        val transactionDao = database.transactionDao()
        val studentDao = database.studentDao()
        val bookDao = database.bookDao()

        return try {
            val currentTime = System.currentTimeMillis()
            // 1. Get unreturned books and filter for overdue (past 48 hours)
            val overdueTransactions = transactionDao.getUnreturnedBooks()
                .filter { currentTime > it.dateToBeReturned }

            if (overdueTransactions.isEmpty()) {
                Log.d("OverdueCheckWorker", "No overdue books to process.")
                return Result.success()
            }

            // 2. Group by student
            val overdueByStudent = overdueTransactions.groupBy { it.studentNumber }

            overdueByStudent.forEach { (studentNumber, transactions) ->
                val student = studentDao.getStudentByNumber(studentNumber)
                if (student != null) {
                    val bookTitles = transactions.mapNotNull { transaction ->
                        bookDao.getBookByIsbn(transaction.bookIsbn)?.title
                    }

                    if (bookTitles.isNotEmpty()) {
                        val bookListString = bookTitles.joinToString("\n- ")
                        val message = "ORBIT Reminder: The following book(s) are overdue:\n- $bookListString\nPlease return them as soon as possible."
                        
                        // 3. Send using SmsManager (Fully Automatic)
                        // Using getSystemService for modern Android, falling back to getDefault
                        val smsManager: SmsManager = applicationContext.getSystemService(SmsManager::class.java)
                        
                        // Split long messages to ensure they deliver
                        val parts = smsManager.divideMessage(message)
                        smsManager.sendMultipartTextMessage(student.contactNumber, null, parts, null, null)
                        
                        Log.d("OverdueCheckWorker", "Automated SMS sent to ${student.name} at ${student.contactNumber}")
                    }
                }
            }
            Result.success()
        } catch (e: Exception) {
            Log.e("OverdueCheckWorker", "Critical failure in automated background SMS", e)
            Result.failure()
        }
    }
}